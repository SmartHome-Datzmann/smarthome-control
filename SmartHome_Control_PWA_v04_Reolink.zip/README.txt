SmartHome Control – Version 0.4 | Reolink Kameraübersicht
===========================================================

NEU: Bereich „📹 Kameras“ mit Kamera-Kacheln, Namen, optionalem Modell und optionaler Heimnetz-IP.
Kamera-Daten werden ausschließlich im Browser des jeweiligen Geräts gespeichert, NICHT im GitHub-Repository.
Die Kameras sind noch nicht verbunden. Kein Livebild, kein Reolink-Login, kein Cloud-API-Zugriff.
Keine Zugangsdaten eingeben. Keine Portfreigaben an Router/Kameras vornehmen.

Update der bestehenden GitHub Pages Webseite:
1. ZIP entpacken.
2. In https://github.com/SmartHome-Datzmann/smarthome-control wechseln.
3. Diese sechs Dateien direkt in den Repository-Hauptordner auf Branch main hochladen:
   index.html, manifest.webmanifest, service-worker.js, icon-192.png, icon-512.png, README.txt
   Vorhandene Dateien durch neue Versionen ersetzen. Optional README.txt zusätzlich hochladen.
4. Die neue PWA-Version nach der GitHub Pages-Veröffentlichung öffnen und ggf. neu laden.
   Die bestehende Installation auf dem Handy bleibt erhalten.

Geplant für den nächsten Schritt:
- Kameramodelle ermitteln (genaue Modellbezeichnungen, Akku/WLAN/PoE, NVR oder Home Hub)
- Prüfen, ob für diese Geräte RTSP/ONVIF oder lokaler Webzugang verfügbar ist.
- Für echtes Livebild über HTTPS ist ein privates, abgesichertes Streaming-Gateway nötig.
  GitHub Pages allein ist nur ein statischer Webhost.

Wichtig: Öffentliche GitHub-Projekte sind für jedermann einsehbar.
Keine Passwörter, Kamera-UIDs, Login-Tokens oder privaten Videostream-URLs dort ablegen.
